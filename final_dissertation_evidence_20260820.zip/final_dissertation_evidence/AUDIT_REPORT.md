# AUDIT REPORT

## 1. Packaging metadata

- Repository: `DejAmour/DissertationV2`
- Current main-branch commit: `0ebb6f5551b81297c5443c1546ffc15a8d847de5`
- Packaging timestamp (UTC): `2026-08-20T18:07:38.251859Z`
- Historical Stage 8 outputs were recovered read-only from reachable Git objects `993789a72d2541dc0a38073277e22aad64ebc1db` and `745516b51de17b966436367fe854d39e3199bbc1`.
- **No experiments were rerun.** Existing result files were copied byte-for-byte; no result was altered, regenerated, rounded, corrected, moved, or deleted.
- Git does not preserve original working-tree modification times. `FILE_MANIFEST.csv` records the observed checkout/archive materialisation timestamp; each run's configuration timestamp is the authoritative run-creation indicator when present.

## 2. Executive conclusion

The repository does **not** contain the complete final dissertation evidence requested. The validated 2 × 2 sensitivity experiment is present and reproduces all four supplied sensitivity cross-checks. However, no final seven-contract principal run for either monitoring profile, no standalone training-curve output for either profile, and no final reference-precision diagnostics were found in the current tree, any fetched remote branch, or reachable Git history.

Two historical seven-contract m=252 runs were recoverable from Git history. They are not valid substitutes for the final m=252 principal run: they use training/pilot/pricing sizes `10000/2000/10000` rather than `5000/1000/50000`, do not record the final 25-epoch policy, and all NCV rows have `torch_not_available` errors. They are retained under `unresolved_candidates/` as superseded evidence.

## 3. Run-classification table

| Run directory | Classification | Provenance | Created UTC | m | epochs | train / validation / pilot / pricing | reps | width | contracts | methods represented | validation |
|---|---|---|---|---:|---|---|---:|---:|---|---|---|
| `stage8_sensitivity_2x2_dissertation_20260818T101252Z` | Primary 2x2 sensitivity candidate | current main tree | 20260818T101252Z | 12,252 | 25,1000 | 5000 / 10000 / 1000 / 50000 | 30 | 32 | reference | GCV, MC, NCV | passed=True; failures=0; warnings=0 |
| `stage8_sensitivity_2x2_dissertation_20260818T095404Z` | Alternate 2x2 sensitivity candidate | current main tree | 20260818T095404Z | 12,252 | 25,1000 | 5000 / 10000 / 1000 / 50000 | 30 | 32 | reference | GCV, MC, NCV | passed=True; failures=0; warnings=0 |
| `stage8_sensitivity_2x2_smoke_20260818T095313Z` | 2x2 smoke test | current main tree | 20260818T095313Z | 12,252 | 25,1000 | 64 / 128 / 64 / 512 | 2 | 32 | reference | GCV, MC, NCV | passed=True; failures=0; warnings=0 |
| `stage8_sensitivity_2x2_smoke_20260818T101239Z` | 2x2 smoke test | current main tree | 20260818T101239Z | 12,252 | 25,1000 | 64 / 128 / 64 / 512 | 2 | 32 | reference | GCV, MC, NCV | passed=True; failures=0; warnings=0 |
| `stage8_dissertation_20260816T140312Z` | Superseded seven-contract m252 candidate | Git object 993789a | 20260816T140312Z | 252 | not recorded | 10000 / not recorded / 2000 / 10000 | 30 | not recorded | maturity_long, maturity_short, reference, strike_high, strike_low, volatility_high, volatility_low | AV, GCV, MC, NCV_SCRATCH, NCV_TRANSFER_BETA, NCV_TRANSFER_BETA1 | passed=True; failures=0; warnings=0 |
| `stage8_dissertation_20260816T140458Z` | Superseded seven-contract m252 candidate | Git object 745516b | 20260816T140458Z | 252 | not recorded | 10000 / not recorded / 2000 / 10000 | 30 | not recorded | maturity_long, maturity_short, reference, strike_high, strike_low, volatility_high, volatility_low | AV, GCV, MC, NCV_SCRATCH, NCV_TRANSFER_BETA, NCV_TRANSFER_BETA1 | passed=True; failures=0; warnings=0 |
| `stage8_smoke_20260816T140246Z` | Historical Stage 8 smoke test | reachable Git history | 20260816T140246Z | 12 | not recorded | 100 / not recorded / 50 / 200 | 2 | not recorded | maturity_long, maturity_short, reference, strike_high, strike_low, volatility_high, volatility_low | AV, GCV, MC, NCV_SCRATCH, NCV_TRANSFER_BETA, NCV_TRANSFER_BETA1 | passed=True; failures=0; warnings=0 |
| `stage8_smoke_20260816T140258Z` | Historical Stage 8 smoke test | reachable Git history | 20260816T140258Z | 12 | not recorded | 100 / not recorded / 50 / 200 | 2 | not recorded | maturity_long, maturity_short, reference, strike_high, strike_low, volatility_high, volatility_low | AV, GCV, MC, NCV_SCRATCH, NCV_TRANSFER_BETA, NCV_TRANSFER_BETA1 | passed=True; failures=0; warnings=0 |
| `stage8_smoke_20260816T140447Z` | Historical Stage 8 smoke test | reachable Git history | 20260816T140447Z | 12 | not recorded | 100 / not recorded / 50 / 200 | 2 | not recorded | maturity_long, maturity_short, reference, strike_high, strike_low, volatility_high, volatility_low | AV, GCV, MC, NCV_SCRATCH, NCV_TRANSFER_BETA, NCV_TRANSFER_BETA1 | passed=True; failures=0; warnings=0 |
| `stage8_smoke_20260816T140450Z` | Historical Stage 8 smoke test | reachable Git history | 20260816T140450Z | 12 | not recorded | 100 / not recorded / 50 / 200 | 2 | not recorded | maturity_long, maturity_short, reference, strike_high, strike_low, volatility_high, volatility_low | AV, GCV, MC, NCV_SCRATCH, NCV_TRANSFER_BETA, NCV_TRANSFER_BETA1 | passed=True; failures=0; warnings=0 |

### Required category classification

| Required category | Classification |
|---|---|
| Principal seven-contract m=12 | **Missing.** Only historical m=12 smoke runs were found. |
| Principal seven-contract m=252 | **Missing.** Historical 30-rep candidates exist, but their configuration differs and their NCV results are errors. |
| 2 × 2 sensitivity | `stage8_sensitivity_2x2_dissertation_20260818T101252Z` is selected as the primary candidate because it is later. The earlier `095404Z` candidate is retained because core statistical outputs are identical while runtime outputs differ. |
| Training curve m=12 | **Missing.** No output folder, configuration, raw results, or validation report found. |
| Training curve m=252 | **Missing.** No output folder, configuration, raw results, or validation report found. |
| High-precision references | A seven-contract `high_precision_references.csv` exists only inside the superseded historical m=252 run and is copied to `reference_prices/` with its limitation stated. No final `reference_precision_diagnostics.csv` exists. |
| Older/smoke/superseded | All six smoke runs, both historical dissertation-scale m=252 candidates, the earlier 2 × 2 candidate, and three legacy single-contract comparisons are classified under `unresolved_candidates/`. |

## 4. Principal-run configuration and method coverage

No output matches the requested principal design of seven contracts, training `5000`, pilot `1000`, pricing `50000`, 30 replications, hidden width `32`, and selected epoch `1000` for m=12 or `25` for m=252. Consequently, the exact principal-run configuration snapshots, final method coverage, and final replication-level numerical completeness cannot be audited from repository evidence.

The latest historical seven-contract m=252 candidate (`140458Z`) contains labels for MC, AV, GCV, NCV_SCRATCH, NCV_TRANSFER_BETA1, and NCV_TRANSFER_BETA across the seven contracts, but its NCV-based rows are not numerical. Error coverage is: `AV/none=210; GCV/none=210; MC/none=210; NCV_SCRATCH/torch_not_available=210; NCV_TRANSFER_BETA/torch_not_available=180; NCV_TRANSFER_BETA1/torch_not_available=180`.

## 5. Row counts for major CSVs

- Primary 2 × 2 candidate: replication_level_results.csv=120; runtime_results.csv=120; checkpoint_curve_results.csv=480; cell_summary.csv=4; seed_manifest.csv=300
- Alternate 2 × 2 candidate: replication_level_results.csv=120; runtime_results.csv=120; checkpoint_curve_results.csv=480; cell_summary.csv=4; seed_manifest.csv=300
- Latest historical seven-contract m=252 candidate: per_replication_results.csv=1200; aggregate_statistical_results.csv=40; equal_observation_results.csv=40; equal_budget_empirical_results.csv=324; matched_accuracy_results.csv=120; runtime_raw_results.csv=840; runtime_summary.csv=28; transfer_diagnostics.csv=360; seed_manifest.csv=690
- `stage8_sensitivity_2x2_smoke_20260818T095313Z`: replication_level_results.csv=8; runtime_results.csv=8; checkpoint_curve_results.csv=16; cell_summary.csv=4; seed_manifest.csv=20
- `stage8_sensitivity_2x2_smoke_20260818T101239Z`: replication_level_results.csv=8; runtime_results.csv=8; checkpoint_curve_results.csv=16; cell_summary.csv=4; seed_manifest.csv=20
- `stage8_smoke_20260816T140246Z`: per_replication_results.csv=80; aggregate_statistical_results.csv=40; equal_observation_results.csv=40; equal_budget_empirical_results.csv=72; matched_accuracy_results.csv=120; runtime_raw_results.csv=56; runtime_summary.csv=28; transfer_diagnostics.csv=24; seed_manifest.csv=46
- `stage8_smoke_20260816T140258Z`: per_replication_results.csv=80; aggregate_statistical_results.csv=40; equal_observation_results.csv=40; equal_budget_empirical_results.csv=72; matched_accuracy_results.csv=120; runtime_raw_results.csv=56; runtime_summary.csv=28; transfer_diagnostics.csv=24; seed_manifest.csv=46
- `stage8_smoke_20260816T140447Z`: per_replication_results.csv=80; aggregate_statistical_results.csv=40; equal_observation_results.csv=40; equal_budget_empirical_results.csv=72; matched_accuracy_results.csv=120; runtime_raw_results.csv=56; runtime_summary.csv=28; transfer_diagnostics.csv=24; seed_manifest.csv=46
- `stage8_smoke_20260816T140450Z`: per_replication_results.csv=80; aggregate_statistical_results.csv=40; equal_observation_results.csv=40; equal_budget_empirical_results.csv=72; matched_accuracy_results.csv=120; runtime_raw_results.csv=56; runtime_summary.csv=28; transfer_diagnostics.csv=24; seed_manifest.csv=46

Zero-byte `break_even_by_contract.csv` and `portfolio_break_even.csv` files in the historical Stage 8 runs were preserved exactly. They open as empty CSVs but contain no rows.

## 6. NCV numerical-completeness check

- Primary 2 × 2 run: `120/120` replication rows have finite numerical NCV price, observation variance, estimator variance, and standard error. No `torch_not_available` string occurs in this run.
- Historical seven-contract m=252 candidates: every NCV_SCRATCH, NCV_TRANSFER_BETA1, and NCV_TRANSFER_BETA replication row reports `torch_not_available`; therefore those files cannot support the dissertation's NCV, frozen beta-one, or frozen estimated-beta results.
- Legacy single-contract comparison files also contain NCV error rows and are not substitutes for principal evidence.

## 7. Numerical reconciliation

### 2 × 2 sensitivity NCV/GCV advantages

| Cell (m, epoch) | observed geometric-mean advantage | expected approximate value | difference |
|---|---:|---:|---:|
| (12, 25) | 0.500870716299 | 0.501 | -0.000129283701 |
| (12, 1000) | 17.744767389218 | 17.745 | -0.000232610782 |
| (252, 25) | 0.179272398125 | 0.179 | +0.000272398125 |
| (252, 1000) | 0.169730653721 | 0.170 | -0.000269346279 |

All four approximate sensitivity values are reproduced by `sensitivity_2x2/stage8_sensitivity_2x2_dissertation_20260818T101252Z/cell_summary.csv`.

### Principal seven-contract tables

The supplied principal m=12 and m=252 GCV/MC, NCV/MC, and NCV/GCV values cannot be reproduced because no matching principal output files were found. Values appearing in dissertation prose were not treated as experimental evidence.

### AV contract-level evidence

Final contract-level AV data needed for the main tables is missing. The superseded historical m=252 aggregate contains the following AV/MC mean variance ratios: `maturity_long=4.303571; maturity_short=4.032713; reference=4.141089; strike_high=2.093124; strike_low=65.157762; volatility_high=3.043004; volatility_low=6.359846`. Its range is `2.093124` to `65.157762`, which does not reproduce the stated final upper endpoint of approximately `65.86`, and the run configuration is not final. Historical m=12 AV data is smoke-scale only. These values must not be substituted into the principal table without the final run files.

### Frozen estimated-beta and beta-one evidence

No valid replication-level frozen-reuse results were found. The historical transfer rows all report `torch_not_available`, so the supplied estimated-beta values and the claim that beta-one NCV/GCV advantage was below `0.016` for every target contract cannot be verified.

### Break-even evidence

- The specific m=12 seven-contract matched-accuracy values `688, 684, 676, 703, 626, 694, 609` are not traceable to any repository-resident or historical output file.
- In the available reference-contract 2 × 2 run, m=252 has `proposed_marginal_not_below_baseline_no_finite_break_even` in all 30 replications at 25 epochs and all 30 replications at 1000 epochs. This supports the qualitative no-finite-break-even conclusion **only for the separate reference-contract sensitivity design**, not the missing seven-contract principal run.
- At m=12, the sensitivity run has no finite break-even at 25 epochs, while the 1000-epoch cell has finite replication-level break-even values. These are not substitutes for the missing contract-specific `609–703` file.

## 8. High-precision reference prices and uncertainty

`reference_prices/historical_m252_stage8_20260816T140458Z/high_precision_references.csv` contains seven GCV high-precision calculations with `1,000,000` paths per contract, plus standard errors and 95% confidence intervals. It was recovered from a superseded m=252 run and is the only such seven-contract file found. No final `reference_precision_diagnostics.csv` or separate final-profile reference folder was found.

## 9. Required files/results still missing

The following requested filenames or direct equivalents were not found for either final principal profile:

- `aggregate_results.csv`
- `per_replication_variance_ratios.csv`
- `variance_ratio_summary.csv`
- a numerical final-profile `transfer_diagnostics.csv` and `transfer_diagnostics_summary.csv`
- final-profile `runtime_raw.csv` and `runtime_summary.csv`
- `equal_pricing_observations_summary.csv`
- `equal_budget_projected_results.csv`
- final-profile `equal_budget_empirical_results.csv`
- final-profile `matched_accuracy_results.csv`
- `break_even_equal_observations.csv`
- `break_even_matched_accuracy.csv`
- `break_even_fixed_accuracy.csv`
- a non-empty final-profile `portfolio_break_even.csv`
- `reference_precision_diagnostics.csv`
- both standalone training-curve folders and their raw/configuration/validation files

Historical files with similar names are included but explicitly classified as superseded and configuration-mismatched.

## 10. Integrity and safety validation

- Source-to-copy SHA-256 mismatches during packaging: `0`.
- All CSV files, including zero-byte historical CSVs, were opened successfully with Python's CSV reader.
- No absolute ZIP paths or `..` traversal components are permitted by the packaging validator.
- No virtual environments, caches, `.env` files, credentials, dependency folders, or unrelated Brent/dissertation files are included.
- Secret-pattern scan covers private-key markers, GitHub tokens, AWS access-key IDs, and Slack tokens.
- `FILE_MANIFEST.csv` hashes every copied or generated bundle file except itself; self-hashing is intentionally omitted because it is recursive.
- ZIP integrity is tested after creation with both Python `ZipFile.testzip()` and the platform `unzip -t` command.

## 11. Interpretation boundary

This package establishes what the GitHub repository does and does not contain. It does not establish that the missing final experiments were never run elsewhere; they may exist only in a local, ignored, or previously generated handover ZIP that was not committed. No statement is made that further testing is or is not required.
